package com.arsari.weighttrackingapp;

/**
 * Items java code.
 * <p>
 * The Item class includes the functionality to model the
 * constructor to manage the item table in the database.
 *
 * Jack Coster - jack.coster@snhu.edu</i>
 * @course	CS-360-X6386 Mobile Architect & Programming
 * @college	Southern New Hampshire University
 */
public class Item {

    int id; // Unique identifier for the item
    String user_email; // Email associated with the user who owns the item
    String desc; // Description of the item
    String qty; // Quantity of the item
    String unit; // Unit of measurement for the item quantity (e.g., kg, lb)

    // Default constructor
    public Item() {
        super();
    }

    // Constructor that initializes all fields, including ID
    public Item(int i, String email, String description, String quantity, String unit) {
        super();
        this.id = i; // Assign the item ID
        this.user_email = email; // Assign the user's email
        this.desc = description; // Assign the item's description
        this.qty = quantity; // Assign the quantity of the item
        this.unit = unit; // Assign the unit of measurement
    }

    // Constructor that initializes all fields except the ID (used when creating a new item)
    public Item(String email, String description, String quantity, String unit) {
        this.user_email = email; // Assign the user's email
        this.desc = description; // Assign the item's description
        this.qty = quantity; // Assign the quantity of the item
        this.unit = unit; // Assign the unit of measurement
    }

    // Getter for the item ID
    public int getId() {
        return id;
    }

    // Setter for the item ID
    public void setId(int id) {
        this.id = id;
    }

    // Getter for the user's email associated with the item
    public String getUserEmail() {
        return user_email;
    }

    // Setter for the user's email associated with the item
    public void setUserEmail(String user_email) {
        this.user_email = user_email;
    }

    // Getter for the item description
    public String getDesc() {
        return desc;
    }

    // Setter for the item description
    public void setDesc(String desc) {
        this.desc = desc;
    }

    // Getter for the item quantity
    public String getQty() {
        return qty;
    }

    // Setter for the item quantity
    public void setQty(String qty) {
        this.qty = qty;
    }

    // Getter for the unit of measurement for the item
    public String getUnit() {
        return unit;
    }

    // Setter for the unit of measurement for the item
    public void setUnit(String unit) {
        this.unit = unit;
    }
}
