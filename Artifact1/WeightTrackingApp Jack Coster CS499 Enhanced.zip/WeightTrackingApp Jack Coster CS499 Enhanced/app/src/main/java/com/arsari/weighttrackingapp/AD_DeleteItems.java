package com.arsari.weighttrackingapp;

import androidx.appcompat.app.AlertDialog;

/**
 * Delete Items Alert Dialog java code.
 * <p>
 * The AD_DeleteItems class includes the functionality to build the
 * alert dialog to delete all the item records in the database.
 * <p>
 * This class is called from the ItemsListActivity class.
 *
 * Jack Coster - jack.coster@snhu.edu</i>
 * @course	CS-360-X6386 Mobile Architect & Programming
 * @college	Southern New Hampshire University
 */
public class AD_DeleteItems {

	// Method to build and return an AlertDialog with Yes/No buttons
	public static AlertDialog doubleButton(final ItemsListActivity context) {
		// Use the Builder class for convenient dialog construction
		AlertDialog.Builder builder = new AlertDialog.Builder(context); // Initialize the AlertDialog builder
		builder.setTitle(R.string.ad_delete_title) // Set the dialog title
				.setIcon(R.drawable.delete_all_items) // Set the icon for the dialog
				.setCancelable(false) // Prevent the dialog from being canceled without user action
				.setMessage(R.string.ad_delete_msg) // Set the message to ask the user for confirmation
				.setPositiveButton(R.string.ad_delete_dialog_yes_button, (dialog, arg1) -> {
					// Action to perform if the user clicks "Yes"
					ItemsListActivity.YesDeleteItems(); // Call method to delete items
					dialog.cancel(); // Close the dialog
				})
				.setNegativeButton(R.string.ad_delete_dialog_no_button, (dialog, arg1) -> {
					// Action to perform if the user clicks "No"
					ItemsListActivity.NoDeleteItems(); // Call method to cancel deletion
					dialog.cancel(); // Close the dialog
				});

		// Create the AlertDialog object and return it
		return builder.create(); // Return the constructed dialog
	}
}

