package com.arsari.weighttrackingapp;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Custom Items List Activity java code.
 * <p>
 * The CustomItemsList class includes the functionality to populate
 * the items from the database into the ItemListActivity. Add the
 * row functionality to edit and delete an item, and to change item
 * quantity. It also calls and builds the edit item alert dialog.
 * <p>
 * This class generates the row in the ItemsListActivity.
 *
 * Jack Coster - jack.coster@snhu.edu</i>
 * @course	CS-360-X6386 Mobile Architect & Programming
 * @college	Southern New Hampshire University
 */
public class CustomItemsList extends BaseAdapter {

	private final Activity context; // The activity context (ItemsListActivity)
	private PopupWindow popwindow; // Popup window used for editing item details
	ArrayList<Item> items; // List of items fetched from the database
	ItemsSQLiteHandler db; // Database handler for performing CRUD operations on items

	// Constructor to initialize the activity context, list of items, and database handler
	public CustomItemsList(Activity context, ArrayList<Item> items, ItemsSQLiteHandler db) {
		this.context = context;
		this.items = items;
		this.db = db;
	}

	// ViewHolder class to hold references to the views in each row of the list
	public static class ViewHolder {
		TextView textViewItemId; // TextView for the item ID
		TextView textViewUserEmail; // TextView for the user email
		TextView textViewItemDesc; // TextView for the item description
		TextView textViewItemQty; // TextView for the item quantity
		TextView textViewItemUnit; // TextView for the item unit
		ImageButton editBtn; // Edit button for editing the item
		ImageButton deleteBtn; // Delete button for deleting the item
	}

	// Method to create and return the view for each row in the list
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		LayoutInflater inflater = context.getLayoutInflater();
		ViewHolder vh;

		// If the row is being created for the first time, inflate it and set up ViewHolder
		if (convertView == null) {
			vh = new ViewHolder();
			row = inflater.inflate(R.layout.item_row_template, null, true); // Inflate the row layout

			// Initialize views in the row and assign them to the ViewHolder
			vh.editBtn = row.findViewById(R.id.editButton);
			vh.textViewItemId = row.findViewById(R.id.textViewItemId);
			vh.textViewUserEmail = row.findViewById(R.id.textViewUserEmail);
			vh.textViewItemDesc = row.findViewById(R.id.textViewItemDesc);
			vh.textViewItemQty = row.findViewById(R.id.textViewItemQty);
			vh.textViewItemUnit = row.findViewById(R.id.textViewItemUnit);
			vh.deleteBtn = row.findViewById(R.id.deleteButton);

			row.setTag(vh); // Store the ViewHolder for reuse
		} else {
			// If the row has been created before, reuse the ViewHolder
			vh = (ViewHolder) convertView.getTag();
		}

		// Set the values for the item fields in the ViewHolder based on the item's data
		vh.textViewItemId.setText("" + items.get(position).getId());
		vh.textViewUserEmail.setText(items.get(position).getUserEmail());
		vh.textViewItemDesc.setText(items.get(position).getDesc());
		vh.textViewItemQty.setText(items.get(position).getQty());
		vh.textViewItemUnit.setText(items.get(position).getUnit());

		// Check if the item quantity is zero and change the background color and send SMS if needed
		String value = vh.textViewItemQty.getText().toString().trim();
		if (value.equals("0")) {
			// Change background color and text color of item qty cell if value is zero
			vh.textViewItemQty.setBackgroundColor(Color.RED);
			vh.textViewItemQty.setTextColor(Color.WHITE);
			ItemsListActivity.SendSMSMessage(context.getApplicationContext()); // Send SMS notification
		} else {
			// Change background color and text color of item qty cell to default
			vh.textViewItemQty.setBackgroundColor(Color.parseColor("#E6E6E6"));
			vh.textViewItemQty.setTextColor(Color.BLACK);
		}

		// Position for handling edit and delete popups
		final int positionPopup = position;

		// Set up the click listener for the edit button to show the edit popup
		vh.editBtn.setOnClickListener(view -> editPopup(positionPopup));

		// Set up the click listener for the delete button to delete the item
		vh.deleteBtn.setOnClickListener(view -> {
			db.deleteItem(items.get(positionPopup)); // Delete the item from the database

			// Refresh the list after deletion
			items = (ArrayList<Item>) db.getAllItems(); // Retrieve the updated list of items
			notifyDataSetChanged(); // Notify the adapter to refresh the view

			Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show(); // Show a message

			// Update the total items count
			int itemsCount = db.getItemsCount();
			TextView TotalItems = context.findViewById(R.id.textViewTotalItemsCount);
			TotalItems.setText(String.valueOf(itemsCount)); // Update the count in the UI
		});

		return row; // Return the row view
	}

	// Method to return the item at a specific position
	public Object getItem(int position) {
		return position;
	}

	// Method to return the item ID at a specific position
	public long getItemId(int position) {
		return position;
	}

	// Method to return the total number of items in the list
	public int getCount() {
		return items.size();
	}

	// Method to display the popup for editing an item
	public void editPopup(final int positionPopup) {
		LayoutInflater inflater = context.getLayoutInflater();
		View layout = inflater.inflate(R.layout.edit_item_popup, context.findViewById(R.id.popup_element));

		// Create the popup window for editing the item
		popwindow = new PopupWindow(layout, 800, 1000, true);
		popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0); // Show the popup at the center

		// Retrieve the EditText fields from the popup layout
		final EditText editItemDesc = layout.findViewById(R.id.editTextItemDescriptionPopup);
		final EditText editItemQty = layout.findViewById(R.id.editTextItemQtyPopup);
		final EditText editItemUnit = layout.findViewById(R.id.editTextItemUnitPopup);

		// Set the current item details in the popup for editing
		editItemDesc.setText(items.get(positionPopup).getDesc());
		editItemQty.setText(items.get(positionPopup).getQty());
		editItemUnit.setText(items.get(positionPopup).getUnit());

		// Set up the save and cancel buttons in the popup
		Button save = layout.findViewById(R.id.editSaveButton);
		Button cancel = layout.findViewById(R.id.editCancelButton);

		// Save button click listener to save the updated item details
		save.setOnClickListener(view -> {
			String itemDesc = editItemDesc.getText().toString();
			String itemQty = editItemQty.getText().toString();
			String itemUnit = editItemUnit.getText().toString();

			// Update the item details
			Item item = items.get(positionPopup);
			item.setDesc(itemDesc);
			item.setQty(itemQty);
			item.setUnit(itemUnit);

			// Update the item in the database and refresh the list
			db.updateItem(item);
			items = (ArrayList<Item>) db.getAllItems();
			notifyDataSetChanged(); // Notify the adapter to refresh the view

			Toast.makeText(context, "Item Updated", Toast.LENGTH_SHORT).show(); // Show a success message
			popwindow.dismiss(); // Dismiss the popup
		});

		// Cancel button click listener to close the popup without making changes
		cancel.setOnClickListener(view -> {
			Toast.makeText(context, "Action Canceled", Toast.LENGTH_SHORT).show(); // Show a cancellation message
			popwindow.dismiss(); // Dismiss the popup
		});
	}

}

