package com.arsari.weighttrackingapp;

import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

/**
 * SMS Notification Alert Dialog java code.
 * <p>
 * The AD_SMSNotification class includes the functionality to build the
 * alert dialog to enable or disable SMS notifications when an item's
 * quantity is zero.
 * <p>
 * This class is called from the ItemsListActivity class.
 *
 * Jack Coster - jack.coster@snhu.edu</i>
 * @course	CS-360-X6386 Mobile Architect & Programming
 * @college	Southern New Hampshire University
 */
public class AD_SMSNotification {

	// Method to create and return an AlertDialog with Enable/Disable buttons
	public static AlertDialog doubleButton(final ItemsListActivity context) {
		// Use the Builder class for convenient dialog construction
		AlertDialog.Builder builder = new AlertDialog.Builder(context); // Initialize the AlertDialog builder
		builder.setTitle(R.string.ad_sms_title) // Set the title for the dialog
				.setIcon(R.drawable.sms_notification) // Set the icon for the dialog
				.setCancelable(false) // Prevents the dialog from being dismissed without user action
				.setMessage(R.string.ad_sms_msg) // Set the message asking the user whether to enable or disable SMS notifications
				.setPositiveButton(R.string.ad_sms_enable_button, (dialog, arg1) -> {
					// Action to perform if the user clicks "Enable"
					Toast.makeText(context, "SMS Alerts Enabled", Toast.LENGTH_LONG).show(); // Display a toast message
					ItemsListActivity.AllowSendSMS(); // Call method to enable sending SMS alerts
					dialog.cancel(); // Close the dialog
				})
				.setNegativeButton(R.string.ad_sms_disable_button, (dialog, arg1) -> {
					// Action to perform if the user clicks "Disable"
					Toast.makeText(context, "SMS Alerts Disabled", Toast.LENGTH_LONG).show(); // Display a toast message
					ItemsListActivity.DenySendSMS(); // Call method to disable sending SMS alerts
					dialog.cancel(); // Close the dialog
				});

		// Create the AlertDialog object and return it
		return builder.create(); // Return the constructed dialog
	}
}
